#include <stdio.h>
#include <conio.h>
int main()
{
	int edad;
	printf("introduce la edad:\n");
	scanf("%d",&edad);
	
	if (edad>=0 && edad <=3)
		printf("BEBE%c\n");
	else
	if (edad>=4 && edad <=12)
		printf("NINO \n");
	else
	if (edad>=13 && edad <=17)
		printf("ADOLESCENTE \n");
	else
	if (edad>=18 && edad <=39)
		printf("JOVEN \n");
	else
	if (edad>=40 && edad <=59)
		printf("ADULTO \n");
	else
	if (edad>=60)
		printf("ADULTO MAYOR \n");
	else
	printf( "\n   ERROR: Edad incorrecta." );
	getch();
	return 0;
}
