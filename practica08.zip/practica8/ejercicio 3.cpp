#include <stdio.h>

int main()	
{
	int p,h,v;
	printf("ingresa las medidas del triangulo \n");
	printf("ingresa el primer numero \n");
	scanf("%d",&p);
	printf("ingresa el segundo numero \n");
	scanf("%d",&h);
	printf("ingresa el tercer numero \n");
	scanf("%d",&v);
	
	if(p==h&&p==v)
		printf("el triangulo es EQUILATERO \n");
	else
	if(p!=h&&p!=v&&h!=v)
		printf("el triangulo es ESCALENO \n");
	else
	if(p==h||p==v||h==v)
		printf("el triangulo es ISOSCELES \n");
	else
	return 0;
}
