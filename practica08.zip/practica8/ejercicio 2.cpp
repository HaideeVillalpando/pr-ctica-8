#include <stdio.h>
#include <math.h>
#include<stdlib.h>
int main()
{
	float a,b,c,x1,x2,disc;
	printf("ingresa los valores \n");
	printf("ingresa a:, \n");
	scanf("%d",&a);
	printf("ingresa b: \n");
	scanf("%d",&b);
	printf("ingresa c: \n");
	scanf("%d",&c);
	
	disc=pow(b,2)-(4*a*c);
	
	 if (disc==0)
    {
       x1=(-b)/(2*a);
       printf("El valor de x es x=%f\n",x1);   
    }
    else
        if(disc<0)
           printf("No tiene solucion\n");
        else
        {
            x1=((-b)+sqrt(disc))/(2*a);
            x2=((-b)-sqrt(disc))/(2*a);
            printf("Los valores de x son:\n");
			printf("x1=%f\n",x1);
			printf("x2=%f\n",x2);
            }
    
    return 0;
}
	
